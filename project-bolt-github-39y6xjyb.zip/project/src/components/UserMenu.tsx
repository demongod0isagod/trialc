import { useState, useRef, useEffect } from 'react';
import { User, LogOut, Settings, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { useNavigate } from 'react-router-dom';

const UserMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentUser, logout } = useAuth();
  const { userStats, subscriptionPlan } = useSubscription();
  const navigate = useNavigate();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      setIsOpen(false);
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  const handleAccountSettings = () => {
    navigate('/account-settings');
    setIsOpen(false);
  };

  const handleCommunity = () => {
    navigate('/community');
    setIsOpen(false);
  };

  if (!currentUser) return null;

  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'King': return 'text-yellow-500';
      case 'Major General': return 'text-purple-500';
      case 'Colonel': return 'text-blue-500';
      case 'Captain': return 'text-green-500';
      case 'Officer': return 'text-orange-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-2 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
          {currentUser.displayName?.charAt(0) || currentUser.email?.charAt(0) || 'U'}
        </div>
        <ChevronDown size={16} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 py-2 z-50">
          {/* User Info */}
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium">
                {currentUser.displayName?.charAt(0) || currentUser.email?.charAt(0) || 'U'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-gray-900 dark:text-white">
                    {currentUser.displayName || 'User'}
                  </p>
                  <span className={`text-xs font-bold ${getRankColor(userStats.rank)}`}>
                    {userStats.rank}
                  </span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                  {currentUser.email}
                </p>
                <p className="text-xs text-gray-400 dark:text-gray-500">
                  {userStats.exPoints} EX Points • {userStats.videosCreated} Videos
                </p>
              </div>
            </div>
          </div>

          {/* Subscription Status */}
          <div className="px-4 py-2">
            <div className={`p-3 rounded-lg border ${subscriptionPlan 
              ? 'bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 border-green-200 dark:border-green-800'
              : 'bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-700'
            }`}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                  {subscriptionPlan ? `${subscriptionPlan} Plan` : 'Free Account'}
                </span>
              </div>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                {subscriptionPlan ? 'Full access to all features' : 'Limited access - upgrade for more'}
              </p>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-1">
            <button 
              onClick={handleCommunity}
              className="w-full px-4 py-2 text-left flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <User size={16} className="text-gray-500 dark:text-gray-400" />
              <span className="text-gray-700 dark:text-gray-300">Community</span>
            </button>
            
            <button 
              onClick={handleAccountSettings}
              className="w-full px-4 py-2 text-left flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <Settings size={16} className="text-gray-500 dark:text-gray-400" />
              <span className="text-gray-700 dark:text-gray-300">Account Settings</span>
            </button>
          </div>

          {/* Logout */}
          <div className="border-t border-gray-200 dark:border-gray-700 pt-1">
            <button
              onClick={handleLogout}
              className="w-full px-4 py-2 text-left flex items-center gap-3 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-red-600 dark:text-red-400"
            >
              <LogOut size={16} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserMenu;