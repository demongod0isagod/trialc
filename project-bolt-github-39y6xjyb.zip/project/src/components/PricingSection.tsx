import { Crown, Check, Star, LogIn, Users } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { useState } from 'react';
import AuthModal from './AuthModal';

const PricingSection = () => {
  const { currentUser } = useAuth();
  const { subscribe } = useSubscription();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');

  const plans = [
    {
      name: 'Hobby',
      price: '$19',
      period: '/mo',
      description: 'Perfect for getting started',
      features: [
        '15 autopilot videos per month',
        '40 minutes of export',
        '30 voiceover minutes',
        '100 AI images',
        'Limited copyright-free clips',
        'Community access'
      ],
      tools: [
        'Reel Factory',
        'HookMagnet', 
        'ReelWriter',
        'TrendSnipe'
      ],
      buttonText: 'Start Hobby Plan',
      popular: false
    },
    {
      name: 'Clipper',
      price: '$39',
      period: '/mo',
      description: 'Most popular for creators',
      isPopular: true,
      features: [
        '25 autopilot videos per month',
        '2 hours of export',
        '120 voiceover minutes',
        '300 AI images',
        'Unlimited copyright-free clips',
        'Community access'
      ],
      tools: [
        'All Hobby tools plus:',
        'StoryReel',
        'PodcastScripter'
      ],
      buttonText: 'Start Clipper Plan',
      popular: true
    },
    {
      name: 'Pro',
      price: '$79',
      period: '/mo',
      description: 'For power users',
      features: [
        '75 autopilot videos per month',
        '3 hours of export',
        '180 voiceover minutes',
        '500 AI images',
        'Unlimited copyright-free clips',
        'Community access'
      ],
      tools: [
        'All Clipper tools plus:',
        'AdCopyX',
        'SmartResume AI'
      ],
      buttonText: 'Start Pro Plan',
      popular: false
    },
    {
      name: 'Agency',
      price: '$199',
      period: '/mo',
      description: 'For teams and businesses',
      features: [
        '100 autopilot videos per month',
        '5 hours of export',
        '260 voiceover minutes',
        '1000 AI images',
        'Unlimited copyright-free clips',
        'Community access'
      ],
      tools: [
        'All Pro tools plus:',
        'BrandBrew',
        'AutoAgency'
      ],
      buttonText: 'Start Agency Plan',
      popular: false
    }
  ];

  const handlePlanSelection = (planName: string) => {
    if (!currentUser) {
      setAuthMode('signup');
      setShowAuthModal(true);
      return;
    }
    
    // User is authenticated, proceed with payment
    subscribe(planName);
    
    // Show success message instead of alert
    const successDiv = document.createElement('div');
    successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white p-6 rounded-lg shadow-lg z-50 max-w-sm';
    successDiv.innerHTML = `
      <div class="flex items-center gap-3 mb-2">
        <div class="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
        </div>
        <h4 class="font-semibold">Payment Successful!</h4>
      </div>
      <p class="text-sm">Welcome to ${planName} plan. You now have access to all premium features.</p>
    `;
    document.body.appendChild(successDiv);
    setTimeout(() => successDiv.remove(), 5000);
  };

  return (
    <>
      <section id="pricing" className="py-16 md:py-24 bg-gray-50 dark:bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-gray-900 to-gray-600 dark:from-gray-100 dark:to-gray-400 bg-clip-text text-transparent">
              Choose Your Plan
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-6">
              Scale your content creation with our flexible pricing options
            </p>
            
            {!currentUser && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-4 rounded-lg max-w-3xl mx-auto mb-6">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <LogIn size={20} className="text-blue-600 dark:text-blue-400" />
                  <span className="font-semibold text-blue-800 dark:text-blue-300">Sign In Required</span>
                </div>
                <p className="text-blue-700 dark:text-blue-300 text-sm">
                  Create an account or sign in to purchase a subscription and access all premium features.
                </p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative bg-white dark:bg-gray-900 rounded-2xl shadow-lg border ${
                  plan.isPopular 
                    ? 'border-blue-500 dark:border-blue-400 transform scale-105' 
                    : 'border-gray-100 dark:border-gray-800'
                } p-6 transition-all duration-300 hover:shadow-xl hover:scale-105`}
              >
                {plan.isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white text-sm font-medium px-4 py-1 rounded-full flex items-center gap-1">
                      <Crown size={16} />
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    {plan.name}
                  </h3>
                  <div className="flex items-end justify-center mb-2">
                    <span className="text-4xl font-bold text-gray-900 dark:text-white">
                      {plan.price}
                    </span>
                    {plan.period && (
                      <span className="text-gray-500 dark:text-gray-400 ml-1">
                        {plan.period}
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {plan.description}
                  </p>
                </div>

                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Features:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li
                        key={index}
                        className="flex items-start text-gray-700 dark:text-gray-300"
                      >
                        <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">AI Tools Included:</h4>
                  <ul className="space-y-2">
                    {plan.tools.map((tool, index) => (
                      <li
                        key={index}
                        className="flex items-start text-gray-700 dark:text-gray-300"
                      >
                        <Star className="w-4 h-4 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{tool}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button 
                  onClick={() => handlePlanSelection(plan.name)}
                  className={`w-full py-3 px-6 rounded-full text-center font-medium transition-all duration-300 ${
                    plan.isPopular
                      ? 'bg-blue-500 hover:bg-blue-600 text-white shadow-lg hover:shadow-xl'
                      : 'bg-gradient-to-r from-gray-900 to-gray-700 dark:from-gray-100 dark:to-gray-300 text-white dark:text-gray-900 hover:opacity-90'
                  } ${!currentUser ? 'relative' : ''}`}
                >
                  {!currentUser && (
                    <LogIn size={16} className="inline mr-2" />
                  )}
                  {plan.buttonText}
                </button>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-100 dark:border-gray-800">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                🔒 Subscription Benefits
              </h3>
              <div className="grid md:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Crown className="text-blue-600 dark:text-blue-400" size={24} />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Full Access</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    Unlock all AI tools, content packs, and premium features
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="text-green-600 dark:text-green-400" size={24} />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Copyright Free</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    All content is copyright-free and safe for commercial use
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="text-purple-600 dark:text-purple-400" size={24} />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Community Access</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    Join our creator community with messaging and collaboration
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
        onModeChange={setAuthMode}
      />
    </>
  );
};

export default PricingSection;