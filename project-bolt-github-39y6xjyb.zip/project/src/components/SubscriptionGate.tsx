import { Lock, Crown, Star, ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useState } from 'react';
import AuthModal from './AuthModal';

interface SubscriptionGateProps {
  title: string;
  description: string;
  onUpgrade: () => void;
}

const SubscriptionGate = ({ title, description, onUpgrade }: SubscriptionGateProps) => {
  const { currentUser } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');

  const handleUpgradeClick = () => {
    if (!currentUser) {
      setAuthMode('signup');
      setShowAuthModal(true);
      return;
    }
    onUpgrade();
  };

  const handleBack = () => {
    // Close the subscription gate
    window.history.back();
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl">
          {/* Header with back button */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white relative">
            <button
              onClick={handleBack}
              className="absolute top-4 left-4 p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <ArrowLeft size={20} />
            </button>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="text-white" size={28} />
              </div>
              
              <h2 className="text-2xl font-bold mb-2">
                {title}
              </h2>
              
              <p className="text-blue-100">
                {description}
              </p>
            </div>
          </div>
          
          <div className="p-6">
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-4 rounded-lg mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Crown className="text-yellow-500" size={20} />
                <span className="font-semibold text-blue-800 dark:text-blue-300">Premium Features Include:</span>
              </div>
              <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                <li>• All AI-powered content tools</li>
                <li>• Unlimited copyright-free clips</li>
                <li>• Professional video generation</li>
                <li>• Advanced automation features</li>
                <li>• Community access with messaging</li>
              </ul>
            </div>
            
            <button
              onClick={handleUpgradeClick}
              className="w-full py-3 px-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-medium hover:shadow-lg transition-all duration-300 mb-4"
            >
              {!currentUser ? (
                <>
                  <Star className="inline mr-2" size={16} />
                  Sign In to Continue
                </>
              ) : (
                <>
                  <Star className="inline mr-2" size={16} />
                  Choose Your Plan
                </>
              )}
            </button>
            
            <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
              Enterprise-grade security • Multiple payment options
            </p>
          </div>
        </div>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
        onModeChange={setAuthMode}
      />
    </>
  );
};

export default SubscriptionGate;