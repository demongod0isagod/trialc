import { ContentPack } from '../types';

export const contentPacks: ContentPack[] = [
  {
    id: 'valorant-clips',
    title: 'Valorant Highlights',
    description: 'High-impact gaming moments from Valorant tournaments and pro players - Copyright Free',
    category: 'gaming',
    image: 'https://images.pexels.com/photos/7915282/pexels-photo-7915282.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: false,
    clips: [
      {
        id: 'val-1',
        title: 'Epic Ace Clutch - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/7915282/pexels-photo-7915282.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 45,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'gta-moments',
    title: 'GTA Viral Moments',
    description: 'Funny and unexpected moments from GTA online gameplay - Copyright Free',
    category: 'gaming',
    image: 'https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: false,
    clips: [
      {
        id: 'gta-1',
        title: 'Hilarious Car Chase - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/3945683/pexels-photo-3945683.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 55,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'anime-action',
    title: 'Anime Action Sequences',
    description: 'High-energy fight scenes and action sequences from top anime - Copyright Free',
    category: 'anime',
    image: 'https://images.pexels.com/photos/7241628/pexels-photo-7241628.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: true,
    clips: [
      {
        id: 'anime-action-1',
        title: 'Epic Battle Sequence - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/7241628/pexels-photo-7241628.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 50,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'minecraft-parkour',
    title: 'Minecraft Parkour Pack',
    description: 'Epic parkour runs and challenging obstacle courses in Minecraft - Copyright Free',
    category: 'gaming',
    image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: true,
    clips: [
      {
        id: 'minecraft-1',
        title: 'Insane Parkour Run - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 42,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'satisfying-videos',
    title: 'Satisfying Videos',
    description: 'Oddly satisfying moments and relaxing content - Copyright Free',
    category: 'satisfying',
    image: 'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: false,
    clips: [
      {
        id: 'satisfying-1',
        title: 'Satisfying Slime Compilation - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 38,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'subway-surfers',
    title: 'Subway Surfers Gameplay',
    description: 'High-score runs and epic moments from Subway Surfers - Copyright Free',
    category: 'gaming',
    image: 'https://images.pexels.com/photos/1040160/pexels-photo-1040160.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: true,
    clips: [
      {
        id: 'subway-1',
        title: 'Epic High Score Run - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/1040160/pexels-photo-1040160.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 45,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'racing-clips',
    title: 'Racing Highlights',
    description: 'Thrilling racing moments and epic crashes from various racing games - Copyright Free',
    category: 'racing',
    image: 'https://images.pexels.com/photos/358220/pexels-photo-358220.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: true,
    clips: [
      {
        id: 'racing-1',
        title: 'Epic Racing Overtake - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/358220/pexels-photo-358220.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 30,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  },
  {
    id: 'nature-timelapses',
    title: 'Nature Timelapses',
    description: 'Beautiful nature scenes and timelapses for background content - Copyright Free',
    category: 'nature',
    image: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    clipCount: 50,
    isNew: true,
    clips: [
      {
        id: 'nature-1',
        title: 'Sunset Timelapse - Copyright Free',
        thumbnail: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&dpr=2',
        duration: 30,
        previewUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4'
      }
    ]
  }
];