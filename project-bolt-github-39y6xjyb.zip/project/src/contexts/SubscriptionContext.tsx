import React, { createContext, useContext, useState } from 'react';
import { useAuth } from './AuthContext';

interface UserStats {
  videosCreated: number;
  exPoints: number;
  rank: string;
  joinDate: string;
}

interface SubscriptionContextType {
  isSubscribed: boolean;
  subscriptionPlan: string | null;
  showSubscriptionGate: boolean;
  userStats: UserStats;
  setShowSubscriptionGate: (show: boolean) => void;
  subscribe: (plan: string) => void;
  unsubscribe: () => void;
  addVideoCreated: () => void;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};

const getRank = (videosCreated: number): string => {
  if (videosCreated >= 999) return 'King';
  if (videosCreated >= 500) return 'Major General';
  if (videosCreated >= 250) return 'Colonel';
  if (videosCreated >= 100) return 'Captain';
  if (videosCreated >= 50) return 'Officer';
  return 'Major';
};

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [subscriptionPlan, setSubscriptionPlan] = useState<string | null>(null);
  const [showSubscriptionGate, setShowSubscriptionGate] = useState(false);
  const [userStats, setUserStats] = useState<UserStats>({
    videosCreated: 0,
    exPoints: 0,
    rank: 'Major',
    joinDate: new Date().toISOString().split('T')[0]
  });

  // Only subscribed users have access to premium features
  const isSubscribed = !!subscriptionPlan;

  const subscribe = (plan: string) => {
    setSubscriptionPlan(plan);
    setShowSubscriptionGate(false);
  };

  const unsubscribe = () => {
    setSubscriptionPlan(null);
  };

  const addVideoCreated = () => {
    setUserStats(prev => {
      const newVideosCreated = prev.videosCreated + 1;
      const newExPoints = prev.exPoints + 1;
      const newRank = getRank(newVideosCreated);
      
      return {
        ...prev,
        videosCreated: newVideosCreated,
        exPoints: newExPoints,
        rank: newRank
      };
    });
  };

  return (
    <SubscriptionContext.Provider value={{
      isSubscribed,
      subscriptionPlan,
      showSubscriptionGate,
      userStats,
      setShowSubscriptionGate,
      subscribe,
      unsubscribe,
      addVideoCreated
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
};