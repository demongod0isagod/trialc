import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyAgFPJFTnb2HE6wOm8GbxWnMIlCjvqvV3M",
  authDomain: "kingg-d06d8.firebaseapp.com",
  projectId: "kingg-d06d8",
  storageBucket: "kingg-d06d8.firebasestorage.app",
  messagingSenderId: "652009729724",
  appId: "1:652009729724:web:2b1e339e6b0d0e28432ab9",
  measurementId: "G-N0B1PLEFY4"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Google Auth Provider
export const googleProvider = new GoogleAuthProvider();

// Initialize Analytics
export const analytics = getAnalytics(app);

export default app;