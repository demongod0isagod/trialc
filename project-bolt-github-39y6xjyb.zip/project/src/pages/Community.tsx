import { ArrowLeft, Send, Users, Crown, Star, MessageCircle, Hash, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { useState } from 'react';

const Community = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { isSubscribed, userStats } = useSubscription();
  const [message, setMessage] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('general');

  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'King': return 'text-yellow-500';
      case 'Major General': return 'text-purple-500';
      case 'Colonel': return 'text-blue-500';
      case 'Captain': return 'text-green-500';
      case 'Officer': return 'text-orange-500';
      default: return 'text-gray-500';
    }
  };

  const getRankBadge = (rank: string) => {
    switch (rank) {
      case 'King': return '👑';
      case 'Major General': return '⭐';
      case 'Colonel': return '🎖️';
      case 'Captain': return '🏅';
      case 'Officer': return '🔰';
      default: return '🎯';
    }
  };

  const groups = [
    { id: 'general', name: 'General Chat', members: 2847, description: 'Main community discussion' },
    { id: 'creators', name: 'Content Creators', members: 1523, description: 'Tips and tricks for creators' },
    { id: 'ai-tools', name: 'AI Tools Discussion', members: 892, description: 'Discuss AI tools and features' },
    { id: 'feedback', name: 'Feedback & Suggestions', members: 456, description: 'Share your feedback' },
    { id: 'showcase', name: 'Content Showcase', members: 1234, description: 'Show off your creations' }
  ];

  const mockMessages = [
    {
      id: 1,
      user: 'Alex Creator',
      rank: 'Captain',
      message: 'Just hit 1M views on my latest reel! The AI tools here are incredible 🚀',
      time: '2 hours ago',
      likes: 24,
      isSubscribed: true,
      group: 'general'
    },
    {
      id: 2,
      user: 'Sarah Digital',
      rank: 'Major General',
      message: 'Anyone tried the new PodcastScripter? Game changer for content repurposing!',
      time: '4 hours ago',
      likes: 18,
      isSubscribed: true,
      group: 'ai-tools'
    },
    {
      id: 3,
      user: 'Mike Trends',
      rank: 'Officer',
      message: 'Looking for collaboration on a viral series. DM me if interested!',
      time: '6 hours ago',
      likes: 12,
      isSubscribed: true,
      group: 'creators'
    }
  ];

  const filteredMessages = mockMessages.filter(msg => msg.group === selectedGroup);

  const handleSendMessage = () => {
    if (!isSubscribed) {
      // Show styled message instead of alert
      const messageDiv = document.createElement('div');
      messageDiv.className = 'fixed top-4 right-4 bg-yellow-500 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
      messageDiv.innerHTML = `
        <div class="flex items-center gap-2 mb-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
          </svg>
          <h4 class="font-semibold">Subscription Required</h4>
        </div>
        <p class="text-sm">You need a subscription to send messages in the community. Upgrade to join the conversation!</p>
      `;
      document.body.appendChild(messageDiv);
      setTimeout(() => messageDiv.remove(), 5000);
      return;
    }
    if (message.trim()) {
      // Show success message
      const successDiv = document.createElement('div');
      successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
      successDiv.innerHTML = `
        <div class="flex items-center gap-2 mb-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <h4 class="font-semibold">Message Sent!</h4>
        </div>
        <p class="text-sm">"${message.substring(0, 50)}${message.length > 50 ? '...' : ''}"</p>
      `;
      document.body.appendChild(successDiv);
      setTimeout(() => successDiv.remove(), 3000);
      setMessage('');
    }
  };

  if (!currentUser) {
    navigate('/');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 py-4">
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors bg-blue-50 dark:bg-blue-900/20 px-3 py-2 rounded-lg"
          >
            <ArrowLeft size={20} />
            <span className="font-medium">Back to Home</span>
          </button>
          
          <div className="flex items-center space-x-2">
            <Users className="w-8 h-8 text-blue-500" />
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text">
              Creator Community
            </span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 md:px-6 py-8 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar - Groups */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-md border border-gray-200 dark:border-gray-700 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900 dark:text-white">Groups</h3>
                <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                  <Plus size={16} />
                </button>
              </div>
              
              <div className="space-y-2">
                {groups.map((group) => (
                  <button
                    key={group.id}
                    onClick={() => setSelectedGroup(group.id)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      selectedGroup === group.id
                        ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Hash size={16} />
                      <span className="font-medium text-sm">{group.name}</span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{group.members} members</p>
                  </button>
                ))}
              </div>
            </div>

            {/* User Stats */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-md border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Your Stats</h3>
              
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className={`text-lg ${getRankColor(userStats.rank)}`}>
                    {getRankBadge(userStats.rank)}
                  </span>
                  <div>
                    <p className={`font-semibold ${getRankColor(userStats.rank)}`}>{userStats.rank}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{userStats.exPoints} EX Points</p>
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{userStats.videosCreated}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Videos Created</p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {isSubscribed ? 'Premium' : 'Free'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Account Type</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            {/* Group Header */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-md border border-gray-200 dark:border-gray-700 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    #{groups.find(g => g.id === selectedGroup)?.name}
                  </h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {groups.find(g => g.id === selectedGroup)?.description}
                  </p>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                  <Users size={16} />
                  <span>{groups.find(g => g.id === selectedGroup)?.members} members</span>
                </div>
              </div>
            </div>

            {/* Access Notice for Free Users */}
            {!isSubscribed && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-6 rounded-lg mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <MessageCircle size={24} className="text-yellow-600 dark:text-yellow-400" />
                  <h3 className="text-lg font-semibold text-yellow-800 dark:text-yellow-300">Community Access</h3>
                </div>
                <p className="text-yellow-700 dark:text-yellow-300 mb-4">
                  You can view community messages, but you need a subscription to participate in conversations and send messages.
                </p>
                <button 
                  onClick={() => navigate('/#pricing')}
                  className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors font-medium"
                >
                  Upgrade to Join Conversations
                </button>
              </div>
            )}

            {/* Message Input */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-md border border-gray-200 dark:border-gray-700 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                  {currentUser.displayName?.charAt(0) || currentUser.email?.charAt(0) || 'U'}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900 dark:text-white text-sm">
                      {currentUser.displayName || 'User'}
                    </span>
                    <span className={`text-xs ${getRankColor(userStats.rank)}`}>
                      {getRankBadge(userStats.rank)} {userStats.rank}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={isSubscribed ? `Message #${groups.find(g => g.id === selectedGroup)?.name}...` : "Upgrade to send messages..."}
                  disabled={!isSubscribed}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!isSubscribed || !message.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 text-sm"
                >
                  <Send size={14} />
                  <span>Send</span>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="space-y-4">
              {filteredMessages.length > 0 ? (
                filteredMessages.map((msg) => (
                  <div key={msg.id} className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-md border border-gray-200 dark:border-gray-700">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                        {msg.user.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium text-gray-900 dark:text-white text-sm">{msg.user}</span>
                          <span className={`text-xs ${getRankColor(msg.rank)}`}>
                            {getRankBadge(msg.rank)} {msg.rank}
                          </span>
                          {msg.isSubscribed && (
                            <span className="text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-full">
                              Premium
                            </span>
                          )}
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">{msg.time}</span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-3 text-sm">{msg.message}</p>
                        <div className="flex items-center gap-4">
                          <button className="flex items-center gap-1 text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                            <Star size={14} />
                            <span className="text-xs">{msg.likes}</span>
                          </button>
                          <button className="text-gray-500 dark:text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors text-xs">
                            Reply
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-md border border-gray-200 dark:border-gray-700 text-center">
                  <MessageCircle size={48} className="text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No messages yet</h3>
                  <p className="text-gray-600 dark:text-gray-400">Be the first to start a conversation in this group!</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;